//
//  DetailViewController.swift
//  assignment_7_2
//
//  Created by Betty Chen on 2/19/16.
//  Copyright © 2016 Betty Chen. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!

    @IBOutlet weak var WebView: UIWebView!
    @IBOutlet weak var ToolBar: UIToolbar!
    
    @IBOutlet weak var FavoriteItemButton: UIBarButtonItem!
    
    var url: String?
    
    //var issue: [String: AnyObject] = [String: AnyObject]()

    var detailItem: AnyObject? {
        didSet {
            // Update the view.
            self.configureView()
        }
    }

    func configureView() {
        // Update the user interface for the detail item.
        if let detail = self.detailItem {
            if let label = self.detailDescriptionLabel {
                label.text = detail.description
                print("detail viewdidload")
                //label.text = "Hello1"
                label.text = detail["title"] as? String
                //url = detail["unescapedUrl"] as? String
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
        
        if let navContr = self.navigationController {
            navContr.navigationBar.barTintColor = UIColor.yellowColor()
        }
        
        //load web into web view
//        if let url = self.url{
//            print("enter web view")
//            print("\(url)")
//            let show_url = NSURL(string: url)
//            let requestObj = NSURLRequest(URL: show_url!)
//                WebView.loadRequest(requestObj)
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

