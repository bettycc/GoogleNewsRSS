//
//  MasterViewTableViewCell.swift
//  assignment_7_2
//
//  Created by Betty on 2/20/16.
//  Copyright © 2016 Betty Chen. All rights reserved.
//

import UIKit

class MasterViewTableViewCell: UITableViewCell {

    @IBOutlet weak var MasterViewTitleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
