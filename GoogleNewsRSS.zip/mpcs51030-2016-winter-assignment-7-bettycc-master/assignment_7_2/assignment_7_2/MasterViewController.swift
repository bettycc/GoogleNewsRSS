//
//  MasterViewController.swift
//  assignment_7_2
//
//  Created by Betty Chen on 2/19/16.
//  Copyright © 2016 Betty Chen. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    var objects = [AnyObject]()
    
    var issues:[[String: AnyObject]]?
    var filteredIssues:[[String: AnyObject]]?
    var query: String?
    
    let searchController = UISearchController(searchResultsController: nil)
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        self.navigationItem.leftBarButtonItem = self.editButtonItem()

//        let addButton = UIBarButtonItem(barButtonSystemItem: .Add, target: self, action: "insertNewObject:")
//        self.navigationItem.rightBarButtonItem = addButton
//        if let split = self.splitViewController {
//            let controllers = split.viewControllers
//            self.detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
//        }
        
        //set the color of the navigaiton bar
        if let navContr = self.navigationController {
            navContr.navigationBar.barTintColor = UIColor(red: 0.76, green: 0.48, blue: 0.63, alpha: 1.0)
        }
        
        //setting for the searchController
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        //networking
        query = "apple"
        if let query = self.query{
        SharedNetworking.sharedInstance.issuesRequestion("https://ajax.googleapis.com/ajax/services/search/news?v=1.1&rsz=large&q=\(query)") { (response) -> Void in
            
            // Test that the `response` is not `nil` and unwrap it to the variable
            // response.  IF it is `nil` then return the function so that we do not
            // reload the table unnecessarily.
            guard let response = response else {
                return
            }
            
            self.issues = response

            dispatch_async(dispatch_get_main_queue()) {
                self.tableView.reloadData()
            }
            
            }
        
        //add reshresh
        //self.refreshControl?.addTarget(self, action: "handleRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        }
        
    }

    override func viewWillAppear(animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.collapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func insertNewObject(sender: AnyObject) {
        objects.insert(NSDate(), atIndex: 0)
        let indexPath = NSIndexPath(forRow: 0, inSection: 0)
        self.tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
    }

    // MARK: - Segues

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                
                //let object = issues![indexPath.row]
                
                let issue: [String: AnyObject]?
                if searchController.active && searchController.searchBar.text != "" {
                    issue = filteredIssues![indexPath.row]
                } else {
                    issue = issues![indexPath.row]
                }

                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = issue
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return 8
        if searchController.active && searchController.searchBar.text != "" {
            return filteredIssues!.count
        }
        else{
            if((issues?.count) != nil){
            return (issues?.count)!
            }else{
            return 0
            }
        }
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cellIdentifier = "MasterViewTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)as! MasterViewTableViewCell
        if((issues?.count) != nil){
            var issue = issues![indexPath.row]
            cell.MasterViewTitleLabel.text = issue["title"] as? String
        }
        
        return cell
        
//        let issue: [String: AnyObject]?
//        if((issues?.count) != nil){
//            if searchController.active && searchController.searchBar.text != "" {
//                print("\(filteredIssues)")
//                issue = filteredIssues![indexPath.row]
//                cell.MasterViewTitleLabel.text = issue!["title"] as? String
//            } else {
//                    issue = issues![indexPath.row]
//                    cell.MasterViewTitleLabel.text = issue!["title"] as? String
//                }
//        }
//
//        return cell
    }

    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            objects.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
    
    func filterContentForSearchText(searchText: String, scope: String = "All") {
       
        query = searchText
        
        if let query = self.query{
            SharedNetworking.sharedInstance.issuesRequestion("https://ajax.googleapis.com/ajax/services/search/news?v=1.1&rsz=large&q=\(query)") { (response) -> Void in
                
                // Test that the `response` is not `nil` and unwrap it to the variable
                // response.  IF it is `nil` then return the function so that we do not
                // reload the table unnecessarily.
                guard let response = response else {
                    return
                }
                
                self.issues = response
                
                dispatch_async(dispatch_get_main_queue()) {
                    self.tableView.reloadData()
                }
                
            }
        }
        
        if let searchText = self.query{
            
            print("1 \(query)")
            print("2 \(searchText)")
            filteredIssues = issues!.filter ({ issue -> Bool in
                return (issue["title"]! as? String)!.lowercaseString.containsString(searchText.lowercaseString)
            })
        }

        tableView.reloadData()
    }
}


extension MasterViewController: UISearchResultsUpdating {
    func updateSearchResultsForSearchController(searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text!)
    }
}

